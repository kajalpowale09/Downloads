from django.db import models


class Company(models.Model):
    name = models.CharField(max_length=100)
    contact_name = models.CharField(max_length=100)
    address = models.TextField(max_length=255)
    ph_no = models.CharField(max_length=17)
    tele = models.CharField(max_length=17)
    mail = models.EmailField(max_length=150)
    is_active = models.BinaryField(default=0)


class Client(models.Model):
    company_id = models.IntegerField()
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    ph_no = models.CharField(max_length=17)
    tele = models.CharField(max_length=17)
    mail = models.CharField(max_length=100)
    is_active = models.BinaryField(default=1)


class Product(models.Model):
    company_id = models.IntegerField()
    product_type_id = models.IntegerField()
    scale_id = models.IntegerField()
    name = models.CharField(max_length=100)
    cost = models.IntegerField()
    min_threshold = models.IntegerField()
    is_active = models.IntegerField(default=1)


class Vendor(models.Model):
    company_id = models.IntegerField()
    name = models.CharField(max_length=100)
    contact_name = models.CharField(max_length=100)
    address = models.TextField(max_length=255)
    ph_no = models.CharField(max_length=17)
    tele = models.CharField(max_length=17)
    mail = models.EmailField(max_length=255)
    is_active = models.BinaryField(default=1)


class UserLogin(models.Model):
    company_id = models.IntegerField()
    role_id = models.IntegerField()
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    ph_no = models.CharField(max_length=100)
    tele = models.CharField(max_length=100)
    mail = models.EmailField(max_length=100)
    user_name = models.CharField(max_length=175)
    login_pass = models.CharField(max_length=100)
    is_active = models.BinaryField(default=1)


class PurchaseMaster(models.Model):
    type_of_purchase = models.BinaryField()
    party_id = models.IntegerField()
    date = models.DateTimeField()
    cost = models.IntegerField()
    discount = models.IntegerField()
    aftercharges = models.IntegerField()
    payable_amount = models.IntegerField()
    is_paid = models.BinaryField()
    is_approved = models.BinaryField()
    is_delete = models.BinaryField()
    insert_date = models.DateTimeField()
    approved_date = models.DateTimeField()
    insert_by = models.IntegerField()
    approved_by = models.IntegerField()


class PurchaseDetails(models.Model):
    master_id = models.IntegerField()
    product_id = models.IntegerField()
    total_count = models.IntegerField()
    cost_per_unit = models.IntegerField()
    total_cost = models.IntegerField()
    last_update = models.DateTimeField()
    is_deleted = models.BinaryField()
