from django.shortcuts import render
from .models import Company, Client, Product, Vendor, UserLogin, PurchaseDetails, PurchaseMaster
import pyodbc
import datetime
import pytz

con = pyodbc.connect('Driver={SQL Server};'
                     'Server=DEVILSHORN999\DEVILSHORN999;'
                     'Database=ShippingLogistics;'
                     'Trusted_Connection=True;')
cursor = con.cursor()
con.autocommit = False

cursor.execute('select company_id, name from Company')
company_name = cursor.fetchall()
cursor.execute("select client_id, first_name from Client")
client_name = cursor.fetchall()
cursor.execute("select product_id, name from Product")
product_name = cursor.fetchall()
cursor.execute('select product_type_id, product_type_name from ProductType')
product_type_name = cursor.fetchall()
cursor.execute('select scale_id, name from ScaleType')
scale_name = cursor.fetchall()
cursor.execute("select role_id,role_name from RoleType")
role_name = cursor.fetchall()
cursor.execute('select vendor_id, name from Vendor')
vendor_name = cursor.fetchall()

sql_join_product = '''
select p.product_id,p.name,c.name,pt.product_type_name,s.name,p.cost,
p.min_threshold,p.IsActive,p.last_update
from Product p
join Company c on p.company_id=c.company_id
join ProductType pt on p.product_type_id=pt.product_type_id
join ScaleType s on p.scale_id=s.scale_id
'''
sql_join_client = '''
select Client.Client_id,Company.name,Client.first_name,Client.last_name,
Client.ph_no,Client.tele,Client.mail,Client.IsActive,Client.last_update
from Client
join Company on Client.company_id=Company.company_id
'''
sql_join_user = '''
select u.login_user_id,u.first_name,u.last_name,c.name,r.role_name,u.ph_no,
u.tele,u.mail,u.username,u.login_pass,u.IsActive,u.last_update
from UserLogin u
join Company c on u.company_id=c.company_id
join RoleType r on u.role_id=r.role_id
'''
sql_join_vendor = '''
select v.vendor_id,v.name,c.name,v.contact_person,v.address,v.ph_no,
v.tele,v.mail,v.IsActive,v.last_update
from Vendor v
join Company c on v.company_id=c.company_id
'''


def selection(request):
    return render(request, 'base.html')


def showcompany(request):
    cursor.execute("select * from Company")
    result = cursor.fetchall()
    return render(request, 'company.html', {'Company': result})


def addcompany(request):
    if request.method == "POST":
        insertstvalues = Company()
        insertstvalues.name = (request.POST.get('name')).capitalize()
        insertstvalues.contact_name = (request.POST.get('contact_name')).capitalize()
        insertstvalues.address = (request.POST.get('address')).capitalize()
        insertstvalues.ph_no = (request.POST.get('ph_no')).capitalize()
        insertstvalues.tele = request.POST.get('tele')
        insertstvalues.mail = request.POST.get('mail')
        param = (insertstvalues.name, insertstvalues.contact_name, insertstvalues.address, insertstvalues.ph_no
                 , insertstvalues.tele, insertstvalues.mail, 1,
                 datetime.datetime.now(pytz.timezone('asia/kolkata')))
        sql = "insert into Company values (?,?,?,?,?,?,?,?)"
        cursor.execute(sql, param)
        cursor.commit()
        cursor.execute("select * from Company")
        result = cursor.fetchall()
        return render(request, 'company.html', {'Company': result})
    else:
        return render(request, 'addcompany.html')


def editcompany(request, id):
    if request.method == "POST":
        insertstvalues = Company()
        insertstvalues.name = request.POST.get('name')
        insertstvalues.contact_name = request.POST.get('contact_name')
        insertstvalues.address = request.POST.get('address')
        insertstvalues.ph_no = request.POST.get('ph_no')
        insertstvalues.tele = request.POST.get('tele')
        insertstvalues.mail = request.POST.get('mail')
        insertstvalues.is_active = request.POST.get('is_active')
        if insertstvalues.is_active is None:
            insertstvalues.is_active = 0
        else:
            pass
        param = (insertstvalues.name, insertstvalues.contact_name, insertstvalues.address, insertstvalues.ph_no
                 , insertstvalues.tele, insertstvalues.mail, insertstvalues.is_active,
                 datetime.datetime.now(pytz.timezone('asia/kolkata')), id)
        sql = "UPDATE Company SET name =?,contact_name =?,address =?,ph_no =?,tele =? ,mail =? ,is_active =?,last_update =? WHERE company_id=?"
        cursor.execute(sql, param)
        cursor.commit()
        cursor.execute("select * from Company")
        result = cursor.fetchall()
        return render(request, 'company.html', {'Company': result})
    else:
        cursor.execute("select * from Company where company_id=?", id)
        result = cursor.fetchall()
        return render(request, 'editcompany.html', {'Company': result})


def deletecompany(request, id):
    cursor.execute("delete from Company where company_id=?", id)
    cursor.commit()
    cursor.execute("select * from Company")
    result = cursor.fetchall()
    return render(request, 'company.html', {'Company': result})


def showclient(request):
    cursor.execute(sql_join_client)  # join
    result = cursor.fetchall()
    return render(request, 'client.html', {'Client': result})


def addclient(request):
    if request.method == "POST":
        insertstvalues = Company()
        insertstvalues.company_id = request.POST.get('company_id')
        insertstvalues.first_name = request.POST.get('first_name')
        insertstvalues.last_name = request.POST.get('last_name')
        insertstvalues.ph_no = request.POST.get('ph_no')
        insertstvalues.tele = request.POST.get('tele')
        insertstvalues.mail = request.POST.get('mail')
        param = (insertstvalues.company_id, insertstvalues.first_name, insertstvalues.last_name,
                 insertstvalues.ph_no, insertstvalues.tele, insertstvalues.mail, 1,
                 datetime.datetime.now(pytz.timezone('asia/kolkata')))
        sql = "insert into Client values (?,?,?,?,?,?,?,?)"
        cursor.execute(sql, param)
        cursor.commit()
        cursor.execute(sql_join_client)
        result = cursor.fetchall()
        return render(request, 'client.html', {'Client': result})
    else:

        return render(request, 'addclient.html', {'Company': company_name})


def editclient(request, id):
    if request.method == "POST":
        insertstvalues = Client()
        insertstvalues.company_id = request.POST.get('company_id')
        insertstvalues.first_name = request.POST.get('first_name')
        insertstvalues.last_name = request.POST.get('last_name')
        insertstvalues.ph_no = request.POST.get('ph_no')
        insertstvalues.tele = request.POST.get('tele')
        insertstvalues.mail = request.POST.get('mail')
        insertstvalues.is_active = request.POST.get('is_active')
        if insertstvalues.is_active is None:
            insertstvalues.is_active = 0
        else:
            pass
        param = (insertstvalues.company_id, insertstvalues.first_name, insertstvalues.last_name, insertstvalues.ph_no
                 , insertstvalues.tele, insertstvalues.mail, insertstvalues.is_active,
                 datetime.datetime.now(pytz.timezone('asia/kolkata')), id)
        sql = "UPDATE Client SET company_id =?,first_name =?,last_name =?,ph_no =?,tele =? ,mail =? ,IsActive =?,last_update =? WHERE client_id=?"
        cursor.execute(sql, param)
        cursor.commit()
        cursor.execute(sql_join_client)
        result = cursor.fetchall()
        return render(request, 'client.html', {'Client': result})
    else:
        cursor.execute("select * from Client where client_id=?", id)
        result = cursor.fetchall()
        return render(request, 'editclient.html', {'Client': result, 'company': company_name})


def deleteclient(request, id):
    cursor.execute("delete from Client where client_id=?", id)
    cursor.commit()
    cursor.execute(sql_join_client)
    result = cursor.fetchall()
    return render(request, 'client.html', {'Client': result})


def showproduct(request):
    cursor.execute(sql_join_product)
    result = cursor.fetchall()
    return render(request, 'product.html', {'Product': result})


def addproduct(request):
    if request.method == "POST":
        insertstvalues = Product()
        insertstvalues.company_id = request.POST.get('company_id')
        insertstvalues.product_type_id = request.POST.get('product_type_id')
        insertstvalues.scale_id = request.POST.get('scale_id')
        insertstvalues.name = request.POST.get('name')
        insertstvalues.cost = request.POST.get('cost')
        insertstvalues.min_threshold = request.POST.get('min_threshold')
        param = (insertstvalues.company_id, insertstvalues.product_type_id, insertstvalues.scale_id,
                 insertstvalues.name, insertstvalues.cost, insertstvalues.min_threshold, 1,
                 datetime.datetime.now(pytz.timezone('asia/kolkata')))
        sql = "insert into Product values (?,?,?,?,?,?,?,?)"
        cursor.execute(sql, param)
        cursor.commit()
        cursor.execute(sql_join_product)
        result = cursor.fetchall()
        return render(request, 'product.html', {'Product': result})
    else:
        return render(request, 'addproduct.html',
                      {'products': product_type_name, 'company': company_name, 'scales': scale_name})


def editproduct(request, id):
    if request.method == "POST":
        insertstvalues = Product()
        insertstvalues.company_id = request.POST.get('company_id')
        insertstvalues.product_type_id = request.POST.get('product_type_id')
        insertstvalues.scale_id = request.POST.get('scale_id')
        insertstvalues.name = request.POST.get('name')
        insertstvalues.cost = request.POST.get('cost')
        insertstvalues.is_active = request.POST.get('is_active')
        insertstvalues.min_threshold = request.POST.get('min_threshold')
        if insertstvalues.is_active is None:
            insertstvalues.is_active = 0
        else:
            pass
        param = (insertstvalues.company_id, insertstvalues.product_type_id,
                 insertstvalues.scale_id, insertstvalues.name, insertstvalues.cost, insertstvalues.min_threshold,
                 insertstvalues.is_active, datetime.datetime.now(pytz.timezone('asia/kolkata')), id)
        sql = "UPDATE Product SET company_id =?, product_type_id=?, scale_id =?, name =?,cost =? ,min_threshold = ? ,IsActive =?,last_update =? WHERE product_id=?"
        cursor.execute(sql, param)
        cursor.commit()
        cursor.execute(sql_join_product)
        result = cursor.fetchall()
        return render(request, 'product.html', {'Product': result})
    else:
        cursor.execute("select * from Product where product_id=?", id)
        result = cursor.fetchall()
        return render(request, 'editproduct.html',
                      {'Product': result, 'ProductType': product_type_name, 'Company': company_name,
                       'ScaleType': scale_name})


def deleteproduct(request, id):
    cursor.execute("delete from Product where product_id=?", id)
    cursor.commit()
    cursor.execute(sql_join_product)
    result = cursor.fetchall()
    return render(request, 'product.html', {'Product': result})


def showvendor(request):
    cursor.execute(sql_join_vendor)
    result = cursor.fetchall()
    return render(request, 'vendor.html', {'Vendor': result})


def addvendor(request):
    cursor.execute('select company_id, name from Company')
    result1 = cursor.fetchall()
    if request.method == "POST":
        insertstvalues = Vendor()
        insertstvalues.company_id = request.POST.get('company_id')
        insertstvalues.name = request.POST.get('name')
        insertstvalues.contact_name = request.POST.get('contact_name')
        insertstvalues.address = request.POST.get('address')
        insertstvalues.ph_no = request.POST.get('ph_no')
        insertstvalues.tele = request.POST.get('tele')
        insertstvalues.mail = request.POST.get('mail')
        param = (insertstvalues.company_id, insertstvalues.name, insertstvalues.contact_name,
                 insertstvalues.address, insertstvalues.ph_no, insertstvalues.tele,
                 insertstvalues.mail, 1, datetime.datetime.now(pytz.timezone('asia/kolkata')))
        sql = "insert into Vendor values (?,?,?,?,?,?,?,?,?)"
        cursor.execute(sql, param)
        cursor.commit()
        cursor.execute(sql_join_vendor)
        result = cursor.fetchall()
        return render(request, 'vendor.html', {'Vendor': result})
    else:
        return render(request, 'addvendor.html', {'company': result1})


def editvendor(request, id):
    if request.method == "POST":
        insertstvalues = Vendor()
        insertstvalues.company_id = request.POST.get('company_id')
        insertstvalues.name = request.POST.get('name')
        insertstvalues.contact_name = request.POST.get('contact_name')
        insertstvalues.address = request.POST.get('address')
        insertstvalues.ph_no = request.POST.get('ph_no')
        insertstvalues.tele = request.POST.get('tele')
        insertstvalues.mail = request.POST.get('mail')
        insertstvalues.IsActive = request.POST.get('is_active')
        if insertstvalues.is_active is None:
            insertstvalues.is_active = 0
        else:
            pass
        param = (insertstvalues.company_id, insertstvalues.name, insertstvalues.contact_name, insertstvalues.address
                 , insertstvalues.ph_no, insertstvalues.tele, insertstvalues.mail, insertstvalues.IsActive,
                 datetime.datetime.now(pytz.timezone('asia/kolkata')), id)
        sql = "UPDATE Vendor SET company_id =?, name=?,contact_person =?,address =?,ph_no =? ,tele =? ,mail =?,IsActive =?,last_update=? WHERE vendor_id=?"
        cursor.execute(sql, param)
        cursor.commit()
        cursor.execute(sql_join_vendor)
        result = cursor.fetchall()
        return render(request, 'vendor.html', {'Vendor': result})
    else:
        cursor.execute("select * from Vendor where vendor_id=?", id)
        r = cursor.fetchall()
        return render(request, 'editvendor.html',
                      {'Vendor': r, 'company': company_name})


def deletevendor(request, id):
    cursor.execute("delete from Vendor where vendor_id=?", id)

    cursor.commit()
    cursor.execute(sql_join_vendor)
    result = cursor.fetchall()
    return render(request, 'vendor.html', {'Vendor': result})


def showuser(request):
    cursor.execute(sql_join_user)
    result = cursor.fetchall()
    return render(request, 'user.html', {'UserLogin': result})


def adduser(request):
    if request.method == "POST":
        insertstvalues = UserLogin()
        insertstvalues.company_id = request.POST.get('company_id')
        insertstvalues.role_id = request.POST.get('role_id')
        insertstvalues.first_name = request.POST.get('first_name')
        insertstvalues.last_name = request.POST.get('last_name')
        insertstvalues.ph_no = request.POST.get('ph_no')
        insertstvalues.tele = request.POST.get('tele')
        insertstvalues.mail = request.POST.get('mail')
        insertstvalues.user_name = request.POST.get('user_name')
        insertstvalues.login_pass = request.POST.get('login_pass')
        param = (
            insertstvalues.company_id, insertstvalues.role_id, insertstvalues.first_name,
            insertstvalues.last_name, insertstvalues.ph_no, insertstvalues.tele,
            insertstvalues.mail, insertstvalues.user_name, insertstvalues.login_pass,
            1, datetime.datetime.now(pytz.timezone('asia/kolkata')))
        sql = "insert into UserLogin values (?,?,?,?,?,?,?,?,?,?,?)"
        cursor.execute(sql, param)
        cursor.commit()
        cursor.execute(sql_join_user)
        result = cursor.fetchall()
        return render(request, 'user.html', {'UserLogin': result})
    else:

        return render(request, 'adduser.html', {'company': company_name, 'role': role_name})


def edituser(request, id):
    if request.method == "POST":
        insertstvalues = UserLogin()
        insertstvalues.company_id = request.POST.get('company_id')
        insertstvalues.role_id = request.POST.get('role_id')
        insertstvalues.first_name = request.POST.get('first_name')
        insertstvalues.last_name = request.POST.get('last_name')
        insertstvalues.ph_no = request.POST.get('ph_no')
        insertstvalues.tele = request.POST.get('tele')
        insertstvalues.mail = request.POST.get('mail')
        insertstvalues.user_name = request.POST.get('user_name')
        insertstvalues.login_pass = request.POST.get('login_pass')
        insertstvalues.is_active = request.POST.get('is_active')
        if insertstvalues.is_active is None:
            insertstvalues.is_active = 0
        else:
            pass
        param = (
            insertstvalues.company_id, insertstvalues.role_id, insertstvalues.first_name,
            insertstvalues.last_name, insertstvalues.ph_no, insertstvalues.tele,
            insertstvalues.mail, insertstvalues.user_name, insertstvalues.login_pass,
            insertstvalues.is_active, datetime.datetime.now(pytz.timezone('asia/kolkata')), id)
        sql = "UPDATE UserLogin SET  company_id =?, role_id =?, first_name=?, last_name =?, ph_no =? ,tele =? ,mail =?, username= ?, login_pass=?, IsActive =?, last_update=? WHERE login_user_id=?"
        cursor.execute(sql, param)
        cursor.commit()
        showuser()
        # cursor.execute(sql_join_user)
        # result = cursor.fetchall()
        # return render(request, 'user.html', {'UserLogin': result})
    else:
        cursor.execute("select * from UserLogin where login_user_id=?", id)
        r = cursor.fetchall()
        return render(request, 'edituser.html', {'UserLogin': r, 'company': company_name, 'RoleType': role_name})


def deleteuser(request, id):
    cursor.execute("delete from UserLogin where login_user_id=?", id)
    cursor.commit()
    cursor.execute(sql_join_user)
    result = cursor.fetchall()
    return render(request, 'user.html', {'UserLogin': result})


def showpurchasemaster(request):
    cursor.execute("select * from PurchaseMaster")
    result = cursor.fetchall()
    return render(request, 'purchasemaster.html', {'purchase': result})


def showpurchasedetails(request):
    cursor.execute("select * from PurchaseMaster")
    result = cursor.fetchall()
    return render(request, 'purchasemaster.html', {'PurchaseMaster': result})


def editpurchasedetails(request, id):
    if request.method == "POST":
        insertstvalues = PurchaseDetails()
        insertstvalues.purchase_detail_id = request.POST.get('purchase_detail_id')
        insertstvalues.purchase_master_id = request.POST.get('purchase_master_id')
        insertstvalues.product_id = request.POST.get('product-id')
        insertstvalues.total_count = request.POST.get('total_count')
        insertstvalues.cost_per_unit = request.POST.get('cost_per_unit')
        insertstvalues.total_cost = request.POST.get('total_cost')
        param = (insertstvalues.purchase_detail_id, insertstvalues.purchase_master_id, insertstvalues.product_id,
                 insertstvalues.total_count, insertstvalues.cost_per_unit, insertstvalues.total_cost, id)

        sql = "UPDATE PurchaseDetails SET total_count =?,cost_per_unit =?,total_cost =?,tele =? ,mail =? ,is_active =?,last_update =? WHERE purchase_detail_id=?"
        cursor.execute(sql, param)
        cursor.commit()
        cursor.execute("select * from PurchaseDetails")
        result = cursor.fetchall()
        return render(request, 'purchasedetails.html', {'PurchaseDetails': result})
    else:
        cursor.execute("select * from PurchaseDetails where purchase_detail_id=?", id)
        result = cursor.fetchall()
        return render(request, 'editpurchasedetails.html', {'PurchaseDetails': result, 'Product': product_name})


def addpurchasedetails(request):
    if request.method == "POST":
        insertstvalues = PurchaseDetails()
        insertstvalues.purchase_detail_id = request.POST.get('purchase_detail_id')
        insertstvalues.purchase_master_id = request.POST.get('purchase_master-id')
        insertstvalues.product_id = request.POST.get('product_id')
        insertstvalues.total_count = request.POST.get('total_count')
        insertstvalues.cost_per_unit = request.POST.get('cost_per_unit')
        insertstvalues.total_cost = request.POST.get('total_cost')
        param = (
            insertstvalues.purchase_detail_id, insertstvalues.purchase_master_id, insertstvalues.product_id,
            insertstvalues.total_count, insertstvalues.cost_per_unit, insertstvalues.total_cost
        )
        sql = "insert into PurchaseDetails values (?,?,?,?,?,?)"
        cursor.execute(sql, param)
        cursor.commit()
        result = cursor.fetchall()
        return render(request, 'purchasedetails.html', {'PurchaseDetails': result})
    else:

        return render(request, 'addpurchasedetails.html', {'company': company_name})


def deletepurchasedetails(request, id):
    cursor.execute("delete from PurchaseDetails where purchase_detail_id=?", id)
    cursor.commit()
    result = cursor.fetchall()
    return render(request, 'purchasedetails.html', {'PurchaseDetails': result})


def showpurchasemaster(request):
    cursor.execute("select * from PurchaseMaster")
    result = cursor.fetchall()
    return render(request, 'purchasemaster.html', {'PurchaseMaster': result})


def editpurchasemaster(request, id):
    if request.method == "POST":
        insertstvalues = PurchaseMaster()
        insertstvalues.type_of_purchase = request.POST.get('type_of_purchase')
        insertstvalues.party_id = request.POST.get('party_id')
        insertstvalues.date = request.POST.get('date')
        insertstvalues.cost = request.POST.get('cost')
        insertstvalues.discount = request.POST.get('discount')
        insertstvalues.aftercharges = request.POST.get('aftercharges')
        insertstvalues.payable_amount = request.POST.get('payable_amount')
        insertstvalues.is_paid = request.POST.get('is_paid')
        insertstvalues.is_approved = request.POST.get('is_approved')
        insertstvalues.is_delete = request.POST.get('is_delete')
        insertstvalues.insert_date = request.POST.get('insert_date')
        insertstvalues.approved_date = request.POST.get('approved_date')
        insertstvalues.insert_by = request.POST.get('insert_by')
        insertstvalues.approved_by = request.POST.get('approved_by')
        param = (insertstvalues.type_of_purchase, insertstvalues.party_id, insertstvalues.date,
                 insertstvalues.cost, insertstvalues.discount, insertstvalues.aftercharges,
                 insertstvalues.payable_amount, insertstvalues.is_paid,
                 insertstvalues.is_approved, insertstvalues.is_delete, insertstvalues.insert_date,
                 insertstvalues.approved_date, insertstvalues.insert_by, insertstvalues.approved_by, id)

        sql = "UPDATE PurchaseMaster SET type_of_purchase =?,party_id =?,date =?,cost =? ,discount =? ,aftercharges =?,payable_amount =?, is_paid =?, is_approved =?, is_delete =?, insert_date =?, approved_date=?, insert_by=?, approved_by =? WHERE purchase_master_id=?"
        cursor.execute(sql, param)
        cursor.commit()
        cursor.execute("select * from PurchaseMaster")
        result = cursor.fetchall()
        return render(request, 'purchasemaster.html', {'PurchaseMaster': result})
    else:
        cursor.execute("select * from PurchaseMaster where purchase_master_id=?", id)
        result = cursor.fetchall()
        return render(request, 'editpurchasemaster.html',
                      {'PurchaseMaster': result, 'vendor': vendor_name, 'client': client_name})


def addpurchasemaster(request):
    if request.method == "POST":
        insertstvalues = PurchaseMaster()
        insertstvalues.type_of_purchase = request.POST.get('type_of_purchase')
        insertstvalues.party_id = request.POST.get('party_id')
        insertstvalues.date = request.POST.get('date')
        insertstvalues.cost = request.POST.get('cost')
        insertstvalues.discount = request.POST.get('discount')
        insertstvalues.aftercharges = request.POST.get('aftercharges')
        insertstvalues.payable_amount = request.POST.get('payable_amount')
        insertstvalues.is_paid = request.POST.get('is_paid')
        insertstvalues.is_approved = request.POST.get('is_approved')
        insertstvalues.is_delete = request.POST.get('is_delete')
        insertstvalues.insert_date = request.POST.get('insert_date')
        insertstvalues.approved_date = request.POST.get('approved_date')
        insertstvalues.insert_by = request.POST.get('insert_by')
        insertstvalues.approved_by = request.POST.get('approved_by')
        param = (insertstvalues.type_of_purchase, insertstvalues.party_id, insertstvalues.date,
                 insertstvalues.cost, insertstvalues.discount, insertstvalues.aftercharges,
                 insertstvalues.payable_amount, insertstvalues.is_paid,
                 insertstvalues.is_approved, insertstvalues.is_delete, insertstvalues.insert_date,
                 insertstvalues.approved_date, insertstvalues.insert_by, insertstvalues.approved_by)

        sql = "insert into PurchaseDetails values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        cursor.execute(sql, param)
        cursor.commit()
        result = cursor.fetchall()
        return render(request, 'purchasemaster.html', {'PurchaseMaster': result})
    else:
        return render(request, 'addpurchasemaster.html', {'vendor': vendor_name, 'client': client_name})


def deletepurchasemaster(request, id):
    cursor.execute("delete from PurchaseMaster where part_id=?", id)
    cursor.commit()
    result = cursor.fetchall()
    return render(request, 'purchasemaster.html', {'PurchaseMaster': result})


def handler404(request, exception):
    return render(request, '404.html')


def test(request):
    return render(request, 'invoice1.html')
